def my_function():
    print("Hello")
    print("Bye")


my_function()