# Day 07 — Untitled

## 🐍 Concept
(fill in)

## 🎯 Learning Objectives
- [ ] Objective 1
- [ ] Objective 2
- [ ] Objective 3

## 📜 Code
> Place or link your scripts here. Any starter files from the course are under `starter/`.

## ✅ What I Learned
- ...

## 📓 Notes & Reflections
- ...

## 🔗 Back
← [100 Days Home](../README.md)
