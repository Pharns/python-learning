friends = ["Alice", "Bob", "Charlie", "David", "Emanuel"]
